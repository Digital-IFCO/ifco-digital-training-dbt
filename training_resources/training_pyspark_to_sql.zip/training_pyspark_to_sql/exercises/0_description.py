# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC There are 2 datasets.
# MAGIC - BigMart MRP
# MAGIC - Retailer Sales
# MAGIC
# MAGIC Each dataset is used in one exercise, 2 in total.  
# MAGIC All exercises implies create staging/intermediate and mart models. Source model is provided.
# MAGIC
# MAGIC Each exercises has the same structure:
# MAGIC - 📄 **Exercise description**
# MAGIC - 📂 **Source Model**
# MAGIC - 📂 **Staging/Intermediate Model**
# MAGIC   - 📄 Create PySpark Model
# MAGIC   - 📝 [TODO] Create SQL Model
# MAGIC   - ✅ Validate SQL Model
# MAGIC - 📂 **Mart Model**
# MAGIC   - 📄 Create PySpark Model
# MAGIC   - 📝 [TODO] Create SQL Model
# MAGIC   - ✅ Validate SQL Model
# MAGIC - 📂 **Export models to DBT**
# MAGIC   - ✅ Validate Staging/Intermediate DBT SQL Model
# MAGIC   - ✅ Validate Mart DBT SQL Model
# MAGIC
# MAGIC The first exercise is going to be done during the class.  
# MAGIC The other one you have to do on your own.
# MAGIC
# MAGIC ## When running dbt
# MAGIC
# MAGIC Copy `profiles.yml.dist` to `profiles.yml`:
# MAGIC
# MAGIC `profiles.yml`
# MAGIC ```yml
# MAGIC training_dbt:
# MAGIC   outputs:
# MAGIC     dev:
# MAGIC       catalog: training_dbt
# MAGIC       host: adb-1149589327075054.14.azuredatabricks.net
# MAGIC       http_path: /sql/1.0/warehouses/e0d012fe05c5911a
# MAGIC       schema: pyspark_dbt_sql_models_<username>
# MAGIC       threads: 1
# MAGIC       token: <dataricks_token>
# MAGIC       type: databricks
# MAGIC   target: dev
# MAGIC ```
# MAGIC [How to generate Databricks tokens](https://docs.databricks.com/en/dev-tools/auth/pat.html#databricks-personal-access-tokens-for-workspace-users)
# MAGIC
# MAGIC
# MAGIC Models execution:
# MAGIC - Run `dbt seed` to create source tables.
# MAGIC - Run `dbt compile --select <model_name>` to compile specific dbt model.
# MAGIC - Run `dbt run` to run all models.
# MAGIC - Run `dbt run --select <model_name>` to run a specific model.
# MAGIC - Run `dbt run test` to run all tests.
# MAGIC - Run `dbt test --select <test_name>` to run a specific test
# MAGIC
# MAGIC In case of doubt you can reach me out thorough Teams or email luis.pico@ifco.com.  
# MAGIC Good luck and have fun 🥳