# Databricks notebook source
# MAGIC %md
# MAGIC # Overview
# MAGIC There are 2 datasets.
# MAGIC - BigMart MRP
# MAGIC - Retailer Sales
# MAGIC
# MAGIC Each dataset is used in one exercise, 2 in total.  
# MAGIC All exercises implies create staging/intermediate and mart models. Source model is provided.
# MAGIC
# MAGIC Each exercises has the same structure:
# MAGIC - 📄 **Exercise description**
# MAGIC - 📂 **Source Model**
# MAGIC - 📂 **Staging/Intermediate Model**
# MAGIC   - 📄 Create PySpark Model
# MAGIC   - 📝 [TODO] Create SQL Model
# MAGIC   - ✅ Validate SQL Model
# MAGIC - 📂 **Mart Model**
# MAGIC   - 📄 Create PySpark Model
# MAGIC   - 📝 [TODO] Create SQL Model
# MAGIC   - ✅ Validate SQL Model
# MAGIC - 📂 **Export models to DBT**
# MAGIC   - ✅ Validate Staging/Intermediate DBT SQL Model
# MAGIC   - ✅ Validate Mart DBT SQL Model
# MAGIC
# MAGIC The first exercise is going to be done during the class.  
# MAGIC The other one you have to do on your own.
# MAGIC
# MAGIC When running dbt:
# MAGIC - Run `dbt seed` to create source tables.
# MAGIC - Run `dbt compile --select <model_name>` to compile specific dbt model.
# MAGIC - Run `dbt run --select <model_name>` to run a specific model.
# MAGIC
# MAGIC In case of doubt you can reach me out thorough Teams or email luis.pico@ifco.com.  
# MAGIC Good luck and have fun 🥳