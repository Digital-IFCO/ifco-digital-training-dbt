# Databricks notebook source
def _hashKeyMd5(df: DataFrame, columns: list = []) -> DataFrame:
    """
    Generates an MD5 hash key for each row in the given DataFrame.

    Args:
        df (DataFrame): The input PySpark DataFrame.
        columns (list, optional): A list of column names to be used for hashing. 
                                  If not provided, all columns in the DataFrame will be used.

    Returns:
        DataFrame: A new DataFrame with an additional column `hashKey` containing 
                   the MD5 hash value computed from the specified columns.

    Example Usage:
        >>> from pyspark.sql import SparkSession
        >>> from pyspark.sql.functions import lit
        >>> spark = SparkSession.builder.getOrCreate()
        >>> data = [("Alice", 25), ("Bob", 30)]
        >>> df = spark.createDataFrame(data, ["name", "age"])
        >>> df_hashed = _hashKeyMd5(df)
        >>> df_hashed.show()

        +-----+---+--------------------+
        | name|age|            hashKey |
        +-----+---+--------------------+
        |Alice| 25|5e48a4e9c50a97f6d...|
        |  Bob| 30|2c6ee7c3ff4b92c4a...|
        +-----+---+--------------------+

    Notes:
        - The function uses `concat_ws("-")` to concatenate column values into a single string 
          before applying the MD5 hash function.
        - If `columns` is provided, only the specified columns will be included in the hash computation.
        - The `hashKey` column is appended to the resulting DataFrame.

    """
    hash_key = "hashKey"
    
    if not columns:
        return df.withColumn(hash_key, md5(concat_ws("-", *[col(c) for c in df.columns])))
    else:
        return df.withColumn(hash_key, md5(concat_ws("-", *[col(c) for c in columns])))

def compare_dataframes(df_source: DataFrame, df_target: DataFrame, columns: list = []) -> (DataFrame, DataFrame):
    """
    Compares two PySpark DataFrames based on a hash key computed from the specified columns
    and returns records that exist only in the source DataFrame and only in the target DataFrame.

    Args:
        df_source (DataFrame): The source DataFrame.
        df_target (DataFrame): The target DataFrame.
        columns (list, optional): A list of column names to be used for hashing.
                                  If not provided, all columns in the DataFrames will be used.

    Returns:
        tuple(DataFrame, DataFrame): 
            - A DataFrame (`df_source_only`) containing rows that are only in the source DataFrame.
            - A DataFrame (`df_target_only`) containing rows that are only in the target DataFrame.

    Example Usage:
        >>> from pyspark.sql import SparkSession
        >>> from pyspark.sql.functions import lit
        >>> spark = SparkSession.builder.getOrCreate()
        >>> data_source = [("Alice", 25), ("Bob", 30), ("Charlie", 35)]
        >>> data_target = [("Alice", 25), ("Bob", 32), ("David", 40)]
        >>> df_source = spark.createDataFrame(data_source, ["name", "age"])
        >>> df_target = spark.createDataFrame(data_target, ["name", "age"])
        >>> df_source_only, df_target_only = compare_dataframes(df_source, df_target, ["name", "age"])
        >>> df_source_only.show()
        >>> df_target_only.show()

    Notes:
        - The function generates a **hash key** for each row based on the specified columns using `_hashKeyMd5()`.
        - It performs a **full outer join** on the hash keys to identify records that exist only in one of the DataFrames.
        - The output consists of two DataFrames:
            - `df_source_only`: Rows that are only in `df_source` but not in `df_target`.
            - `df_target_only`: Rows that are only in `df_target` but not in `df_source`.

    """
    name_source = "source"
    name_target = "target"
    hash_key = "hashKey"

    name_source_hash_key = f"{name_source}_{hash_key}"
    name_target_hash_key = f"{name_target}_{hash_key}"

    df_source_hashed = _hashKeyMd5(df_source, columns)
    df_target_hashed = _hashKeyMd5(df_target, columns)

    df_source_hash_key = df_source_hashed.select(col(hash_key).alias(name_source_hash_key))
    df_target_hash_key = df_target_hashed.select(col(hash_key).alias(name_target_hash_key))

    df_missing_hash = df_source_hash_key.join(
        df_target_hash_key,
        df_source_hash_key[name_source_hash_key] == df_target_hash_key[name_target_hash_key],
        "full"
    ).withColumn(
        name_source,
        when(col(name_source_hash_key).isNull(), lit(name_target))
        .when(col(name_target_hash_key).isNull(), lit(name_source))
        .otherwise(lit("both"))
    ).filter(f"{name_source} != 'both'")

    df_source_only = df_source_hashed.join(
        df_missing_hash.select(name_source_hash_key, name_source).filter(f"{name_source} = '{name_source}'"),
        df_source_hashed[hash_key] == df_missing_hash[name_source_hash_key],
        "inner"
    ).select(*df_source_hashed.columns)

    df_target_only = df_target_hashed.join(
        df_missing_hash.select(name_target_hash_key, name_source).filter(f"{name_source} = '{name_target}'"),
        df_target_hashed[hash_key] == df_missing_hash[name_target_hash_key],
        "inner"
    ).select(*df_target_hashed.columns)

    return df_source_only, df_target_only