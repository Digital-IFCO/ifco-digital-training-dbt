# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

import os
from pyspark.sql.functions import *
from pyspark.sql.window import Window

data_path = f"file:{os.path.abspath('')}/data"
dataset_name = "retailer_sales.csv"
print(data_path)

# COMMAND ----------

# MAGIC %run ./utils/py_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # Retailer Sales
# MAGIC
# MAGIC This dataset contains information about retail sales. Each row represents an order for a product and contains details such as the quantity ordered, unit price, order date, and customer data.
# MAGIC
# MAGIC ## 📊 Retailer Sales Dataset
# MAGIC
# MAGIC | Column            | Data Type  | Description |
# MAGIC |-------------------|-----------|-------------|
# MAGIC | `ORDERNUMBER`       | `INT`     | Order number of the purchase. |
# MAGIC | `QUANTITYORDERED`   | `INT`     | Number of units ordered. |
# MAGIC | `PRICEEACH`         | `FLOAT`   | Unit price of the product. |
# MAGIC | `ORDERLINENUMBER`   | `INT`     | Line number in the order. |
# MAGIC | `SALES`            | `FLOAT`   | Total sales amount for the order. |
# MAGIC | `ORDERDATE`        | `STRING`  | Date of the order (format M/d/yyyy H:mm). |
# MAGIC | `STATUS`           | `STRING`  | Order status (`Shipped`, `Pending`, etc.). |
# MAGIC | `QTR_ID`          | `INT`     | Fiscal quarter of the year (1-4). |
# MAGIC | `MONTH_ID`        | `INT`     | Month in which the purchase was made. |
# MAGIC | `YEAR_ID`         | `INT`     | Year in which the purchase was made. |
# MAGIC | `PRODUCTLINE`      | `STRING`  | Product category. |
# MAGIC | `MSRP`            | `INT`     | Manufacturer's Suggested Retail Price. |
# MAGIC | `PRODUCTCODE`      | `STRING`  | Unique product code. |
# MAGIC | `CUSTOMERNAME`     | `STRING`  | Customer's name. |
# MAGIC | `PHONE`           | `STRING`  | Customer's phone number. |
# MAGIC | `ADDRESSLINE1`     | `STRING`  | Customer's address. |
# MAGIC | `ADDRESSLINE2`     | `STRING`  | Second address line (may be empty). |
# MAGIC | `CITY`            | `STRING`  | Customer's city. |
# MAGIC | `STATE`           | `STRING`  | Customer's state (may be empty). |
# MAGIC | `POSTALCODE`      | `STRING`  | Customer's postal code (may be empty). |
# MAGIC | `COUNTRY`         | `STRING`  | Customer's country. |
# MAGIC | `TERRITORY`       | `STRING`  | Sales region associated with the order (EMEA, APAC, etc.). |
# MAGIC | `CONTACTLASTNAME`  | `STRING`  | Customer contact's last name. |
# MAGIC | `CONTACTFIRSTNAME` | `STRING`  | Customer contact's first name. |
# MAGIC | `DEALSIZE`        | `STRING`  | Deal size classification (`Small`, `Medium`, `Large`). |
# MAGIC
# MAGIC Source: [Kaggle Retailer Sales](https://www.kaggle.com/datasets/kyanyoga/sample-sales-data?resource=download)
# MAGIC
# MAGIC ## Usecase
# MAGIC In a tipical DBT architecture, given the source data create staging, intermediate and mart models based on the following requirements:
# MAGIC
# MAGIC ### Staging Model
# MAGIC   - Convert dates to date type.
# MAGIC   - Handle null values:
# MAGIC     - ADDRESSLINE2: Fill null values with literal value 'Unknown'.
# MAGIC     - STATE: Fill null values with literal value 'Unknown'.
# MAGIC     - TERRITORY: Fill null values with literal value 'Unknown'.
# MAGIC   - Select required columns.
# MAGIC   - Renamed columns.
# MAGIC
# MAGIC ### Intermediate Model
# MAGIC - Aggregates customer sales by country and year.
# MAGIC - Computes total sales, total orders, and average order value.
# MAGIC
# MAGIC ### Mart Model
# MAGIC - Includes customer details by country.
# MAGIC - Categorizes customers into High, Medium, and Low sales.

# COMMAND ----------

# MAGIC %md
# MAGIC # Source Model 🟧

# COMMAND ----------

df_source = spark.read.csv(f"{data_path}/{dataset_name}", header=True, inferSchema=True)
#Create temp view to be able to create staging SQL model
df_source.createOrReplaceTempView("view_source")
display(df_source.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC # Staging Model ⬜️

# COMMAND ----------

# DBTITLE 1,Create PySpark Model
def stg_model(df: DataFrame) -> DataFrame:
    return (
        df
        .withColumn("ORDERDATE", to_date(col("ORDERDATE"), "M/d/yyyy H:mm")) # Convert to date
        .fillna({"ADDRESSLINE2": "Unknown", "STATE": "Unknown", "TERRITORY": "Unknown"}) # Handle nulls
        .select(
            col("ORDERNUMBER").alias("order_number"),
            col("QUANTITYORDERED").alias("quantity_ordered"),
            col("PRICEEACH").alias("price_each"),
            col("YEAR_ID").alias("year_id"),
            col("ORDERDATE").alias("order_date"),
            col("SALES").alias("total_sales"),
            col("PRODUCTCODE").alias("product_code"),
            col("CUSTOMERNAME").alias("customer_name"),
            col("COUNTRY").alias("country"),
            col("ADDRESSLINE2").alias("address_line2"),
            col("STATE").alias("state"),
            col("TERRITORY").alias("territory")
        )
    )

df_staging = stg_model(df_source)
# Display staging model
display(df_staging.limit(10))

# COMMAND ----------

# DBTITLE 1,[TODO] Create SQL Model
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW view_staging AS
# MAGIC SELECT * FROM view_source;

# COMMAND ----------

# DBTITLE 1,Validat SQL Model
df_staging_source, df_staging_target = compare_dataframes(spark.sql("SELECT * FROM view_staging"), df_staging)

display(df_staging_source)
display(df_staging_target)

# COMMAND ----------

# MAGIC %md
# MAGIC # Intermediate Model ⬜️

# COMMAND ----------

# DBTITLE 1,Create PySpark Model
def int_model(df: DataFrame) -> DataFrame:
    return (
        df
        .groupBy("customer_name", "country", "year_id")
        .agg(
            sum("total_sales").cast("decimal(10,2)").alias("total_sales"),
            countDistinct("order_number").alias("total_orders"),
            (sum("total_sales") / countDistinct("order_number")).cast("decimal(10,2)").alias("avg_order_value")
        )
    )

df_intermediate = int_model(df_staging)
# Display intermediate model
display(df_intermediate.limit(10))

# COMMAND ----------

# DBTITLE 1,[TODO] Create SQL Model
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW view_intermediate AS
# MAGIC SELECT * FROM view_staging;

# COMMAND ----------

# DBTITLE 1,Validat SQL Model
df_intermediate_source, df_intermediate_target = compare_dataframes(spark.sql("SELECT * FROM view_intermediate"), df_intermediate)

display(df_intermediate_source)
display(df_intermediate_target)

# COMMAND ----------

# MAGIC %md
# MAGIC # Mart Model 🟨

# COMMAND ----------

# DBTITLE 1,Create PySpark Model
def mart_model(df: DataFrame) -> DataFrame:
    return (
        df
        .groupBy("customer_name", "country")
        .agg(
            sum("total_sales").alias("total_sales"),
            avg("avg_order_value").alias("avg_order_value")
        )
        .withColumn("sales_category", 
            when(col("total_sales") > 100000, "High")
            .when(col("total_sales") > 50000, "Medium")
            .otherwise("Low")
        )
    )

df_mart = mart_model(df_intermediate)
# Display mart model
display(df_mart.limit(10))

# COMMAND ----------

# DBTITLE 1,[TODO] Create SQ Model
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TEMP VIEW view_mart AS
# MAGIC SELECT * FROM view_intermediate;

# COMMAND ----------

# DBTITLE 1,Validate SQL Model
df_mart_source, df_mart_target = compare_dataframes(spark.sql("SELECT * FROM view_mart"), df_mart)

display(df_mart_source)
display(df_mart_target)

# COMMAND ----------

# MAGIC %md
# MAGIC #Export models to DBT 🚀

# COMMAND ----------

# DBTITLE 1,Validate Staging DBT SQL Model
df_staging_source, df_staging_target = compare_dataframes(spark.table(""), df_staging)

display(df_staging_source)
display(df_staging_target)

# COMMAND ----------

# DBTITLE 1,Validate Intermediate DBT SQL Model
df_intermediate_source, df_intermediate_target = compare_dataframes(spark.table(""), df_intermediate)

display(df_intermediate_source)
display(df_intermediate_target)

# COMMAND ----------

# DBTITLE 1,Validate Mart DBT SQL Model
df_mart_source, df_mart_target = compare_dataframes(spark.table(""), df_mart)

display(df_mart_source)
display(df_mart_target)

# COMMAND ----------

# MAGIC %md
# MAGIC