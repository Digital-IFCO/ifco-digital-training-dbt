# Databricks notebook source
# MAGIC %md
# MAGIC # Setup

# COMMAND ----------

import os
from pyspark.sql.functions import *
from pyspark.sql.window import Window

data_path = f"file:{os.path.abspath('')}/data"
dataset_name = "big_mart_mrp.csv"
print(data_path)

# COMMAND ----------

# MAGIC %run ./utils/py_utils

# COMMAND ----------

# MAGIC %md
# MAGIC # BigMart MRP
# MAGIC
# MAGIC This dataset contains information about products Material Requirements Planning (MRP) in different stores. The data includes information about the products, their price, visibility, fat content and store characteristics.
# MAGIC
# MAGIC ## 📊 BigMart MRP Dataset
# MAGIC
# MAGIC | Column | Data Type | Key Column | Description |
# MAGIC |--------|-----------|------------|-------------|
# MAGIC | Item_Identifier | String | X | Product code. |
# MAGIC | Item_Weight | double | | Product Weight |
# MAGIC | Item_Fat_Content | string | | Fat Classification |
# MAGIC | Item_Visibility | double | | Product visibility ratio in the store |
# MAGIC | Item_Type | string | | Product category |
# MAGIC | Item_MRP | double | | Material Requirements Planning (MRP) of the product |
# MAGIC | Outlet_Identifier | string | X | Store code. |
# MAGIC | Outlet_Establishment_Year | Integer | | Year the store was established |
# MAGIC | Outlet_Size | string | | Store size |
# MAGIC | Outlet_Location_Type | string | | Store Location |
# MAGIC | Outlet_Type | string | | Store Type |
# MAGIC
# MAGIC Source: [Kaggle BigMart Sales Data](https://www.kaggle.com/datasets/brijbhushannanda1979/bigmart-sales-data/data)
# MAGIC
# MAGIC ## Usecase
# MAGIC In a tipical DBT architecture, given the source data create staging and mart models based on the following requirements:
# MAGIC ### Staging Model
# MAGIC   - Drop duplicate rows based on the composite key of the data.
# MAGIC   - Handle null values:
# MAGIC     - Item_Weight: Fill null values with the first non-null value of the same product.
# MAGIC     - Outlet_Size: Fill null values with literal value 'Unknown'.
# MAGIC
# MAGIC ### Mart Model
# MAGIC - For each item (composite key) select the one with highest MRP.
# MAGIC - Clean fat content labels. Accepted labels are: 'Low Fat' and 'Regular'.
# MAGIC - The model must have the following columns:
# MAGIC   - Item_Identifier
# MAGIC   - Item_Weight
# MAGIC   - Item_Fat_Content
# MAGIC   - Item_Type
# MAGIC   - Item_MRP
# MAGIC   - Outlet_Identifier
# MAGIC   - Outlet_Location_Type
# MAGIC   - Outlet_Type

# COMMAND ----------

# MAGIC %md
# MAGIC # Source Model 🟧

# COMMAND ----------

df_source = spark.read.csv(f"{data_path}/{dataset_name}", header=True, inferSchema=True)
#Create temp view to be able to create staging SQL model
df_source.createOrReplaceTempView("view_source")
display(df_source.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC # Staging Model ⬜️

# COMMAND ----------

# DBTITLE 1,Create PySpark Model
def stg_model(df: DataFrame) -> DataFrame:
    # Step 1: Remove duplicates based on the compound key (Item_Identifier and Outlet_Identifier)
    df_staging = df.dropDuplicates(["Item_Identifier", "Outlet_Identifier"])
    # Step 2: Handling Null Values
    window_spec = Window.partitionBy("Item_Identifier")
    df_staging = (
        df_staging.withColumn(
            "Item_Weight",
            when(
                col("Item_Weight").isNull(),
                expr("first(Item_Weight, true)").over(window_spec)
            ).otherwise(col("Item_Weight"))
        )
    )
    return df_staging.fillna({"Outlet_Size": "Unknown"})

df_staging = stg_model(df_source)
# Display staging model
display(df_staging.limit(10))

# COMMAND ----------

# DBTITLE 1,[TODO] Create SQL Model
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW view_staging AS
# MAGIC -- Step 1: Remove duplicates based on the compound key (Item_Identifier and Outlet_Identifier)
# MAGIC WITH deduplicated AS (
# MAGIC     SELECT
# MAGIC         *,
# MAGIC         ROW_NUMBER() OVER (PARTITION BY Item_Identifier, Outlet_Identifier ORDER BY Item_Identifier) AS row_num
# MAGIC     FROM view_source
# MAGIC ),
# MAGIC filtered_deduplicated AS (
# MAGIC     SELECT *
# MAGIC     FROM deduplicated
# MAGIC     WHERE row_num = 1
# MAGIC ),
# MAGIC -- Step 2: Handling Null Values
# MAGIC filled_nulls AS (
# MAGIC     SELECT
# MAGIC         Item_Identifier,
# MAGIC         COALESCE(
# MAGIC           Item_Weight,
# MAGIC           FIRST_VALUE(Item_Weight) IGNORE NULLS OVER (PARTITION BY Item_Identifier)
# MAGIC         ) AS Item_Weight,
# MAGIC         Item_Fat_Content,
# MAGIC         Item_Visibility,
# MAGIC         Item_Type,
# MAGIC         Item_MRP,
# MAGIC         Outlet_Identifier,
# MAGIC         Outlet_Establishment_Year,
# MAGIC         COALESCE(Outlet_Size, 'Unknown') AS Outlet_Size,
# MAGIC         Outlet_Location_Type,
# MAGIC         Outlet_Type
# MAGIC     FROM filtered_deduplicated
# MAGIC )
# MAGIC SELECT * FROM filled_nulls

# COMMAND ----------

# DBTITLE 1,Validat SQL Model
df_staging_source, df_staging_target = compare_dataframes(spark.sql("SELECT * FROM view_staging"), df_staging)

display(df_staging_source)
display(df_staging_target)

# COMMAND ----------

# MAGIC %md
# MAGIC # Mart Model 🟨

# COMMAND ----------

# DBTITLE 1,Create PySpark Model
def mart_model(df: DataFrame) -> DataFrame:
    # Step 1.1: Define Window to Select the Record with the Highest Item_MRP per Item_Identifier
    window_spec = Window.partitionBy("Item_Identifier", "Outlet_Identifier").orderBy(col("Item_MRP").desc())
    # Step 1:2: Add a Row Index and Filter Only the First (the Most Item_MRP)
    df_mart = df.withColumn("row_num", row_number().over(window_spec)).filter(col("row_num") == 1).drop("row_num")
    # Step 2: Standardize Item_Fat_Content values
    df_mart = (
        df_mart
        .withColumn(
            "Item_Fat_Content",
            when(col("Item_Fat_Content").isin(["reg"]), "Regular")
            .when(col("Item_Fat_Content").isin(["LF", "low fat"]), "Low Fat")
            .otherwise(col("Item_Fat_Content"))
        )
    )
    # Step 3: Select columns
    return (
        df_mart
        .select(
            "Item_Identifier",
            "Item_Weight",
            "Item_Fat_Content",
            "Item_Type",
            "Item_MRP",
            "Outlet_Identifier",
            "Outlet_Location_Type",
            "Outlet_Type"
        )
    )

df_mart = mart_model(df_staging)
# Display mart model
display(df_mart.limit(10))

# COMMAND ----------

# DBTITLE 1,[TODO] Create SQ Model
# MAGIC %sql
# MAGIC
# MAGIC CREATE OR REPLACE TEMP VIEW view_mart AS
# MAGIC -- Step 1.1 & 1.2: Select the record with the highest Item_MRP per composite key
# MAGIC WITH ranked_items AS (
# MAGIC     SELECT 
# MAGIC         *,
# MAGIC         ROW_NUMBER() OVER (
# MAGIC             PARTITION BY Item_Identifier, Outlet_Identifier 
# MAGIC             ORDER BY Item_MRP DESC
# MAGIC         ) AS row_num
# MAGIC     FROM view_staging
# MAGIC )
# MAGIC , filtered_items AS (
# MAGIC     SELECT *
# MAGIC     FROM ranked_items 
# MAGIC     WHERE row_num = 1
# MAGIC )
# MAGIC -- Step 2: Standardize Item_Fat_Content values
# MAGIC , standardized_fat_content AS (
# MAGIC     SELECT 
# MAGIC         Item_Identifier,
# MAGIC         Item_Weight,
# MAGIC         CASE 
# MAGIC             WHEN Item_Fat_Content = 'reg' THEN 'Regular'
# MAGIC             WHEN Item_Fat_Content IN ('LF', 'low fat') THEN 'Low Fat'
# MAGIC             ELSE Item_Fat_Content
# MAGIC         END AS Item_Fat_Content,
# MAGIC         Item_Type,
# MAGIC         Item_MRP,
# MAGIC         Outlet_Identifier,
# MAGIC         Outlet_Location_Type,
# MAGIC         Outlet_Type
# MAGIC     FROM filtered_items
# MAGIC )
# MAGIC -- Step 3: Select columns
# MAGIC SELECT * FROM standardized_fat_content

# COMMAND ----------

# DBTITLE 1,Validate SQL Model
df_mart_source, df_mart_target = compare_dataframes(spark.sql("SELECT * FROM view_mart"), df_mart)

display(df_mart_source)
display(df_mart_target)

# COMMAND ----------

# MAGIC %md
# MAGIC #Export models to DBT 🚀

# COMMAND ----------

# DBTITLE 1,Validate Staging DBT SQL Model
df_dbt_staging, df_staging_target = compare_dataframes(spark.table("training_dbt.pyspark_dbt_sql_models.stg_big_mart__mrp"), df_staging)

display(df_dbt_staging)
display(df_staging_target)

# COMMAND ----------

# DBTITLE 1,Validate Mart DBT SQL Model
df_dbt_mart, df_mart_target = compare_dataframes(spark.table("training_dbt.pyspark_dbt_sql_models.mart_product_mrp"), df_mart)

display(df_dbt_mart)
display(df_mart_target)

# COMMAND ----------

# MAGIC %md
# MAGIC