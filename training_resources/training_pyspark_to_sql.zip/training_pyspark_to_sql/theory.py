# Databricks notebook source
# MAGIC %md
# MAGIC # What to Migrate to DBT
# MAGIC
# MAGIC In an ELT (Extract Load and Transform) process, DBT handles the last part: **Transform**. This means it is responsible for creating data models after the data has been loaded.  
# MAGIC For data extraction and loading, other tools must be used, such as: Azure Data Factory, Databricks DLT (Delta Live Table), or custom PySpark code.  
# MAGIC
# MAGIC - Data ingestion from the source **is NOT migrated**.
# MAGIC   - With the [Databricks adapter](https://docs.getdbt.com/reference/resource-configs/databricks-configs) it is possible to ingest data from a file store like blob storage using *streaming_table* materialization.
# MAGIC - Data models generated within the data platform **ARE migrated**.
# MAGIC
# MAGIC <img src='./media/databricks_medallion_architecture.png' alt='Medallion Architecture 2' width='900'>

# COMMAND ----------

# MAGIC %md
# MAGIC # Differences between PySpark and DBT SQL
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC | Aspect | PySpark | DBT SQL |
# MAGIC |--------|---------|---------|
# MAGIC | Language | Based on Python, leveraging the Spark API to process data in a distributed manner (in a cluster). | Uses SQL (with Jinja templates for variables and macros) to define models and transformations. [The dialect is the one used by the warehouse (Databricks).](https://www.databricks.com/blog/2021/11/16/evolution-of-the-sql-language-at-databricks-ansi-standard-by-default-and-easier-migrations-from-data-warehouses.html) |
# MAGIC | Paradigm | Programs (scripts) that transform DataFrames/RDDs with operations like filter, join, groupBy, etc. | Declarative definition of “models” that become SQL queries when dbt is run. |
# MAGIC | Execution Environment | A Spark cluster (can be local, Spark Standalone, on YARN, Kubernetes, Databricks, etc.). | A data warehouse (BigQuery, Snowflake, Redshift, Databricks SQL Warehouse, etc.) where queries are executed. |
# MAGIC | Usage | Ideal for complex processing, business logic in Python, machine learning (MLlib), streaming, etc. | Ideal for transforming data directly in the warehouse’s SQL engine (ELT), versioning SQL pipelines, and creating views/tables with dependency control. |
# MAGIC
# MAGIC ## Data Handling
# MAGIC
# MAGIC | Aspect | PySpark | DBT SQL |
# MAGIC |--------|---------|---------|
# MAGIC | Data Sources | Loads data from files (CSV, Parquet, Avro, JSON…), databases (JDBC), streaming (Kafka), etc. | Uses the warehouse’s storage and format (tables, views, sometimes staged files if the warehouse supports it). |
# MAGIC | Transformations | Can combine data in memory and perform complex transformations with Python (custom functions, ML libraries, etc.). | Focuses on pure SQL transformations; there are no (natively) complex Python functions or streaming pipelines. |
# MAGIC | Persistence | Write to HDFS, S3, or store as Hive/Spark tables, Delta Lake, etc. | Each model is typically created as a table or view in the warehouse. |
# MAGIC
# MAGIC ## Language and Syntax
# MAGIC
# MAGIC ### PySpark
# MAGIC - Written in Python with Spark libraries.
# MAGIC - Example:
# MAGIC ```python
# MAGIC df = spark.read.parquet("/ruta/archivo.parquet")
# MAGIC df_filtrado = df.filter(df["columna"] > 100)
# MAGIC df_agrupado = df_filtrado.groupBy("categoria").count()
# MAGIC df_agrupado.show()
# MAGIC ```
# MAGIC DBT SQL
# MAGIC - Written in pure SQL (SELECT, JOIN, GROUP BY…), often with Jinja templates for variables and macros.
# MAGIC - Example:
# MAGIC ```sql
# MAGIC SELECT
# MAGIC     categoria,
# MAGIC     COUNT(*) as conteo
# MAGIC FROM {{ source('esquema_fuente', 'tabla_fuente') }}
# MAGIC WHERE columna > 100
# MAGIC GROUP BY categoria
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC # Types of Materializations

# COMMAND ----------

# MAGIC %md
# MAGIC ## Spark
# MAGIC
# MAGIC | Ingestion Type | Description | Use Cases | Example |
# MAGIC |----------------|-------------|-----------|---------|
# MAGIC | Incremental | Loads or appends only new data since the last load, without modifying existing records. | - Data that grows in regular intervals (daily, weekly, etc.)<br>  - Adding new log or event data over time | df.write<br>.mode("append")<br>.format("parquet")<br>.save("path/to/save")|
# MAGIC | Overwrite | Completely replaces existing data or table content at the specified location. | - Full data refresh when old data is obsolete<br> - Full data refresh when data volume is low | df.write<br>.mode("overwrite")<br>.format("parquet")<br>.save("path/to/save") |
# MAGIC | Overwrite Partition | Replaces only the specified partition(s) in a partitioned table while leaving other partitions intact. | - Updating specific partitions (e.g. by date or region)<br>  - Large datasets partitioned by time or other categories | df.write<br>.mode("overwrite")<br>.partitionBy("year","month")<br>.format("parquet")<br>.save("path/to/save") |
# MAGIC | Merge/CDC | Captures and applies data changes (inserts, updates, deletes) from source systems or logs for incremental processing. | - Slowly Changing Dimensions (SCD)<br>  - Complex update operations<br> - Transactional scenarios (commonly using Delta) | deltaTable.alias("t")<br>.merge(   source = df.alias("s"),   condition = "t.id = s.id" )<br>.whenMatchedUpdateAll()<br>.whenNotMatchedInsertAll()<br>.execute() |

# COMMAND ----------

# MAGIC %md
# MAGIC ## DBT
# MAGIC
# MAGIC In DBT (Data Build Tool), [materializations](https://docs.getdbt.com/docs/build/materializations) define how tables or views are created and managed in the data warehouse. Each materialization serves a specific purpose. Below is a summary of the main types and their uses:
# MAGIC
# MAGIC | Materialization | Description | Use Cases | Example |
# MAGIC |-----------------|-------------|-----------|---------|
# MAGIC | View | A logical object rebuilt with a CREATE VIEW AS statement on each run. It references the underlying data without storing it physically. | - Lightweight transformations<br>  - Data that changes frequently<br> - Early/stage models or reference models | {{ config(materialized='view') }}<br><br>SELECT<br>    column1,<br>    column2,<br>    ...<br>FROM source_table;<br> |
# MAGIC | table | A physical table created with CREATE TABLE AS on each run. Data is stored and must be rebuilt when underlying data changes. | - Fast querying for BI tools or dashboards<br> - Slower transformations that feed many downstream models | {{ config(materialized='table') }}<br><br>SELECT<br>    customer_id,<br>    SUM(order_value) AS total_order_value,<br>    COUNT(*) AS order_count<br>FROM orders<br>GROUP BY 1;<br> |
# MAGIC | Incremental | A physical table created with CREATE TABLE AS on each run. Data is stored and must be rebuilt when underlying data changes. | - Fast querying for BI tools or dashboards<br> - Slower transformations that feed many downstream models | {{ config(<br>    materialized='incremental',<br>    unique_key='id',<br>    incremental_strategy='insert_overwrite'  <!-- or 'merge' depending on your DB -->)<br>}}<br><br>SELECT<br>    id,<br>    updated_at,<br>    value<br>FROM raw_events;<br> |
# MAGIC | Ephemeral | Does not create a physical object; DBT injects this model’s SQL into dependent models using CTEs. Keeps the warehouse clean. | - Very light transformations<br> - Models only used by one or two downstream models<br>- Situations where direct querying is not necessary | {{ config(materialized='ephemeral') }}<br><br>SELECT<br>    user_id,<br>    UPPER(user_name) AS user_name_upper<br>FROM users;<br> |
# MAGIC | Materialized View | A database-native object combining aspects of views and tables, often auto-refreshed. Created and maintained via CREATE MATERIALIZED VIEW if supported by the platform. | - Similar to incremental, but managed by the database for refreshing<br> - Situations needing performance (like a table) plus data freshness (like a view)<br> - Reduces the need for DBT-run-based refreshes if auto-refresh is enabled | {{ config(materialized='ephemeral') }}<br><br>SELECT<br>    user_id,<br>    UPPER(user_name) AS user_name_upper<br>FROM users;<br> |
# MAGIC | Snapshots | Captures the historical state of data, allowing tracking changes in records over time. Implements type 2 SCD. | - Ideal for audits or maintaining a complete history of data<br> - Works well for systems with frequent record updates | snapshots:<br>- name: orders_snapshot<br>relation: source('jaffle_shop', 'orders')<br>config:<br>schema: snapshots<br>database:<br>analytics<br>unique_key: id<br>strategy: timestamp<br>updated_at: updated_at<br>dbt_valid_to_current: "to_date('9999-12-31')".|

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Types
# MAGIC
# MAGIC In order to choose the correct materialization its important to have in mind The type of data that a table stores and its volumetry.  
# MAGIC Here is an overview of each data type:
# MAGIC
# MAGIC | Data Type | Description | Use Cases | Volumetry |
# MAGIC |-----------|-------------|-----------|-----------|
# MAGIC | Transactional | Represents day-to-day business operations and individual events, such as purchases, orders, or clicks. Frequent updates and insertions. Stored in OLTP systems. | - Recording business transactions<br>- Input for reporting and analytics<br>- Source for Fact data | High Volume: 10,000 – 10,000,000 rows/day |
# MAGIC | Master | Centralized, consistent reference data about critical entities like customers, products, or suppliers. Typically static but updated periodically. | - Ensuring consistency across systems<br>- Supporting transactional and analytical systems<br>- Data integration projects | Medium Volume: 1,000 – 500,000 rows|
# MAGIC | Dimensional | Contextual and descriptive data that provides additional information about facts (e.g., time, location, product). Updated periodically with changes in dimension attributes. | - Used in data warehouses for analytical queries<br>- Provides context to fact data<br>- Enables slicing and dicing in BI tools | Medium Volume: 10,000 – 5,000,000 rows |
# MAGIC | Fact | Quantitative data points (metrics or measures) resulting from business transactions, linked to dimensions. Stored in OLAP systems. | - Analytical reporting and dashboards<br>- Calculating KPIs, trends, and performance metrics<br>- Powering data aggregations | Large Volume: 1,000,000 – 1,000,000,000 rows |

# COMMAND ----------

# MAGIC %md
# MAGIC # Migration Examples

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## PySpark Overwrite to DBT SQL table
# MAGIC
# MAGIC ### Usecase
# MAGIC
# MAGIC Fact table that includes:
# MAGIC - Sales data by customer and product.
# MAGIC - Aggregated metrics, such as cumulative sales per customer.
# MAGIC - Calculation of advanced indicators, such as the average ticket and the participation of a product in total sales.
# MAGIC
# MAGIC [Databricks adapter table materialization](https://docs.getdbt.com/docs/build/materializations#table)
# MAGIC
# MAGIC ### Transactional Table
# MAGIC
# MAGIC | transaction_id | product_id | customer_id | date       | quantity | total_amount |
# MAGIC |----------------|------------|-------------|------------|----------|--------------|
# MAGIC | 1              | 101        | 1001        | 2023-01-01 | 5        | 500.0        |
# MAGIC | 2              | 102        | 1001        | 2023-01-01 | 2        | 300.0        |
# MAGIC | 3              | 101        | 1002        | 2023-01-02 | 1        | 100.0        |
# MAGIC | 4              | 103        | 1002        | 2023-01-03 | 3        | 450.0        |
# MAGIC | 5              | 101        | 1003        | 2023-01-04 | 4        | 400.0        |
# MAGIC | 6              | 102        | 1001        | 2023-01-05 | 1        | 150.0        |
# MAGIC
# MAGIC ### Products Table
# MAGIC
# MAGIC | product_id | product_name | category   |
# MAGIC |------------|--------------|------------|
# MAGIC | 101        | Product A    | Category 1 |
# MAGIC | 102        | Product B    | Category 1 |
# MAGIC | 103        | Product C    | Category 2 |
# MAGIC
# MAGIC ### Customers Table
# MAGIC
# MAGIC | customer_id | customer_name | region    |
# MAGIC |-------------|---------------|-----------|
# MAGIC | 1001        | Customer 1    | Region 1  |
# MAGIC | 1002        | Customer 2    | Region 2  |
# MAGIC | 1003        | Customer 3    | Region 3  |
# MAGIC
# MAGIC ### Migration step by step
# MAGIC
# MAGIC | PySpark Code | DBT SQL Code |
# MAGIC |---------|---------|
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_1_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_1_sql.png'> |
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_2_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_2_sql.png'> |
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_3_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_3_sql.png'> |
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_4_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_4_sql.png'>  |
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_5_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_5_sql.png'> |
# MAGIC | <img src='./media/pyspark_overwrite_to_dbt_dql_table_6_pyspark.png'> | <img src='./media/pyspark_overwrite_to_dbt_dql_table_6_sql.png'> |

# COMMAND ----------

# MAGIC %md
# MAGIC ### PySpark code

# COMMAND ----------

# Step 1: Join the transactions, products, and stores tables
fact_table = transactions_df \
    .join(products_df, on="product_id", how="inner") \
    .join(customers_df, on="customer_id", how="inner") \
    .select(
        col("transaction_id"),
        col("date"),
        col("customer_id"),
        col("customer_name"),
        col("region"),
        col("product_id"),
        col("product_name"),
        col("category"),
        col("quantity"),
        col("total_amount")
    )

# Step 2: Calculate cumulative sales for each customer ordered by date
window_customer = Window.partitionBy("customer_id").orderBy("date")
fact_table = fact_table.withColumn(
    "cumulative_sales", sum("total_amount").over(window_customer)
)

# Step 3: Calculate average ticket (average total amount per customer)
average_ticket = fact_table.groupBy("customer_id") \
    .agg(avg("total_amount").alias("avg_ticket"))
fact_table = fact_table.join(average_ticket, on="customer_id", how="inner")

# Step 4: Calculate the global sales total
window_total_sales = Window.partitionBy()
total_sales = fact_table \
                .agg(sum("total_amount") \
                .alias("global_sales")) \
                .collect()[0]["global_sales"]

# Step 5: Calculate the product sales share for each record
fact_table = fact_table.withColumn(
    "product_sales_share", (col("total_amount") / lit(total_sales)) * 100
)

# Step 6: Save the fact table in Delta format
fact_table.write \
.format("delta") \
.mode("overwrite") \
.save("/path/to/advanced_fact_table_delta")

# COMMAND ----------

# MAGIC %md
# MAGIC ### DBT SQL code

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 6: Configure materialization
# MAGIC {{ config(
# MAGIC     materialized='table'
# MAGIC ) }}
# MAGIC
# MAGIC -- Step 1: Join the transactions, products, and stores tables
# MAGIC with joined_data as (
# MAGIC     select
# MAGIC         t.transaction_id,
# MAGIC         t.date,
# MAGIC         t.product_id,
# MAGIC         p.product_name,
# MAGIC         p.category,
# MAGIC         t.store_id,
# MAGIC         s.store_name,
# MAGIC         s.region,
# MAGIC         t.quantity,
# MAGIC         t.total_amount,
# MAGIC         t.customer_id
# MAGIC     from {{ ref('transactions') }} t
# MAGIC     inner join {{ ref('products') }} p on t.product_id = p.product_id
# MAGIC     inner join {{ ref('stores') }} s on t.store_id = s.store_id
# MAGIC ),
# MAGIC
# MAGIC -- Step 2: Calculate cumulative sales for each customer ordered by date
# MAGIC cumulative_sales_data as (
# MAGIC     select 
# MAGIC         jd.*,
# MAGIC         SUM(jd.total_amount)
# MAGIC             over (partition by jd.customer_id order by jd.date)
# MAGIC         as cumulative_sales
# MAGIC     from joined_data jd
# MAGIC ),
# MAGIC
# MAGIC -- Step 3.1: Calculate average ticket (average total amount per customer)
# MAGIC average_ticket_data as (
# MAGIC     select 
# MAGIC         customer_id,
# MAGIC         AVG(total_amount) as avg_ticket
# MAGIC     from cumulative_sales_data
# MAGIC     group by customer_id
# MAGIC ),
# MAGIC
# MAGIC -- Step 3.2: Join the average ticket data back to the cumulative sales data
# MAGIC fact_table_with_avg_ticket as (
# MAGIC     select 
# MAGIC         csd.*,
# MAGIC         atd.avg_ticket
# MAGIC     FROM cumulative_sales_data csd
# MAGIC     inner join average_ticket_data atd on csd.customer_id = atd.customer_id
# MAGIC ),
# MAGIC
# MAGIC -- Step 4: Calculate the global sales total
# MAGIC global_sales as (
# MAGIC     select 
# MAGIC         sum(total_amount) as global_sales
# MAGIC     from fact_table_with_avg_ticket
# MAGIC ),
# MAGIC
# MAGIC -- Step 5.1: Calculate the product sales share for each record
# MAGIC fact_table_final as (
# MAGIC     select 
# MAGIC         fta.*,
# MAGIC         (fta.total_amount / gs.global_sales) * 100 as product_sales_share
# MAGIC     from fact_table_with_avg_ticket fta
# MAGIC     cross join global_sales gs
# MAGIC )
# MAGIC
# MAGIC -- Step 5.2: Select the final fact table
# MAGIC select 
# MAGIC     transaction_id,
# MAGIC     date,
# MAGIC     customer_id,
# MAGIC     product_id,
# MAGIC     product_name,
# MAGIC     category,
# MAGIC     store_id,
# MAGIC     store_name,
# MAGIC     region,
# MAGIC     quantity,
# MAGIC     total_amount,
# MAGIC     cumulative_sales,
# MAGIC     avg_ticket,
# MAGIC     product_sales_share
# MAGIC from fact_table_final

# COMMAND ----------

# MAGIC %md
# MAGIC ## PySpark Overwrite Partition to DBT Incremental
# MAGIC
# MAGIC ### Usecase
# MAGIC
# MAGIC Transactional table that includes:
# MAGIC - Retailer orders.
# MAGIC - Each order has date information including year and month.
# MAGIC
# MAGIC [Databricks adapter insert_overwrite strategy](https://docs.getdbt.com/reference/resource-configs/databricks-configs#the-insert_overwrite-strategy)
# MAGIC
# MAGIC ### **Transactional Table**
# MAGIC
# MAGIC | order_id     | customer_id     | order_date     | order_year_month | total_amount     |
# MAGIC |--------------|-----------------|----------------|------------------|------------------|
# MAGIC | 1            | 101             | 2024-01-01     | 2024-01          | 100              |
# MAGIC | 2            | 102             | 2024-01-01     | 2024-01          | 50               |
# MAGIC | 3            | 101             | 2024-01-02     | 2024-01          | 200              |
# MAGIC | 4            | 103             | 2024-01-05     | 2024-01          | 300              |
# MAGIC | 5            | 104             | 2024-01-10     | 2024-01          | 120              |
# MAGIC
# MAGIC ### Migration step by step
# MAGIC
# MAGIC | PySpark Code | DBT SQL Code |
# MAGIC |---------|---------|
# MAGIC | <img src='./media/pyspark_overwrite_partition_to_dbt_dql_incremental_1_pyspark.png'> | <img src='./media/pyspark_overwrite_partition_to_dbt_dql_incremental_1_sql.png'> |
# MAGIC | <img src='./media/pyspark_overwrite_partition_to_dbt_dql_incremental_2_pyspark.png'> | <img src='./media/pyspark_overwrite_partition_to_dbt_dql_incremental_2_sql.png'> |

# COMMAND ----------

# MAGIC %md
# MAGIC ### PySpark code

# COMMAND ----------

# Read destination table
df_source = spark.read.table("raw_orders")
df_target = spark.read.table("incremental_orders")

max_date_target = df_target.agg.agg(F.max("order_year_month").alias("max_date")) \
                   .collect()[0]["max_date"]

# Step 1: Select new rows based on target table max date
df_incremental = df_source.filter(
    col("order_year_month") >= lit(max_date_target)
)

# Step 2: Save table
(df_incremental
    .write
    .format("delta")
    .partitionBy("order_year_month")
    .option("partitionOverwriteMode", "dynamic")
    .mode("overwrite")
    .saveAsTable("incremental_orders"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### DBT SQL code

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 2: Configure materialization
# MAGIC {{ config(
# MAGIC     materialized='incremental',
# MAGIC     incremental_strategy='insert_overwrite',     -- Overwrites only affected partitions
# MAGIC     partition_by=['order_year_month'],           -- Define partition column(s)
# MAGIC     unique_key='order_id'
# MAGIC ) }}
# MAGIC
# MAGIC -- Step 1: Select new rows based on target table max date
# MAGIC with source_data as (
# MAGIC     select * from {{ ref('raw_orders') }}
# MAGIC     {% if is_incremental() %}
# MAGIC       where order_year_month > (select max(order_year_month) from {{ this }})
# MAGIC     {% endif %}
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ## PySpark merge to DBT SQL incremental
# MAGIC
# MAGIC ### Usecase
# MAGIC
# MAGIC Transactional table that includes:
# MAGIC - Retailer sales by category.
# MAGIC - Aggregate sales per day.
# MAGIC - Each time ingest new data only.
# MAGIC
# MAGIC [Databricks adapter merge strategy](https://docs.getdbt.com/reference/resource-configs/databricks-configs#the-merge-strategy)
# MAGIC
# MAGIC ### **Transactional Table**
# MAGIC
# MAGIC | transaction_id | date       | category         | amount  |
# MAGIC |----------------|------------|------------------|---------|
# MAGIC | 1              | 2025-01-01 | Electronics      | 100.0   |
# MAGIC | 2              | 2025-01-02 | Clothing         | 50.0    |
# MAGIC | 3              | 2025-01-03 | InvalidCategory  | 200.0   |
# MAGIC | 4              | 2025-01-04 | None             | 150.0   |
# MAGIC | None           | 2025-01-05 | Electronics      | 300.0   |
# MAGIC
# MAGIC ### Migration step by step
# MAGIC
# MAGIC | PySpark Code | DBT SQL Code |
# MAGIC |---------|---------|
# MAGIC | <img src='./media/pyspark_merge_to_dbt_dql_incremental_1_pyspark.png'> | <img src='./media/pyspark_merge_to_dbt_dql_incremental_1_sql.png'> |
# MAGIC | <img src='./media/pyspark_merge_to_dbt_dql_incremental_2_pyspark.png'> | <img src='./media/pyspark_merge_to_dbt_dql_incremental_2_sql.png'> |
# MAGIC | <img src='./media/pyspark_merge_to_dbt_dql_incremental_3_pyspark.png'> | <img src='./media/pyspark_merge_to_dbt_dql_incremental_3_sql.png'> |

# COMMAND ----------

# MAGIC %md
# MAGIC ### PySpark code

# COMMAND ----------

# Step 1: Filter null values in the primary key and invalid categories
cleaned_transactions_df = transactions_df.filter(
    (col("transaction_id").isNotNull()) &
    (col("category").isNotNull()) &
    (col("category").isin("Electronics", "Clothing", "Home", "Beauty"))
)

# Step 2: Ensure only one row per primary key
window_spec = Window.partitionBy("transaction_id").orderBy(col("transaction_date").desc())
filtered_transactions_df = cleaned_transactions_df.withColumn(
    "row_number", row_number().over(window_spec)
).filter(col("row_number") == 1).drop("row_number")

# Step 3: Save the transactional table in Delta format
if DeltaTable.isDeltaTable(spark, delta_table_path):
    delta_table = DeltaTable.forPath(spark, delta_table_path)
    delta_table.alias("target").merge(
        filtered_transactions_df.alias("source"),
        "target.transaction_id = source.transaction_id"
    ).whenMatchedUpdateAll() \
     .whenNotMatchedInsertAll() \
     .execute()
else:
    filtered_transactions_df.write.format("delta").mode("overwrite").save(delta_table_path)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DBT SQL code

# COMMAND ----------

# MAGIC %sql
# MAGIC {{ config(
# MAGIC     materialized='incremental',
# MAGIC     file_format='delta',
# MAGIC     unique_key='transaction_id',
# MAGIC     incremental_strategy='merge'
# MAGIC ) }}
# MAGIC
# MAGIC with new_transactions as (
# MAGIC   select * from {{ ref('transaction_table') }}
# MAGIC   {% if is_incremental() %}
# MAGIC   where transaction_date >= (select coalesce(max(transaction_date),'1900-01-01') from {{ this }} )
# MAGIC   {% endif %}
# MAGIC )
# MAGIC
# MAGIC -- Step 1: Filter null values in the primary key and invalid categories
# MAGIC with filtered_transactions as (
# MAGIC     select
# MAGIC         transaction_id,
# MAGIC         transaction_date,
# MAGIC         category,
# MAGIC         amount
# MAGIC     new_transactions
# MAGIC     whenre 
# MAGIC         transaction_id is not null
# MAGIC         and category is not null
# MAGIC         and category in ('Electronics', 'Clothing', 'Home', 'Beauty')
# MAGIC )
# MAGIC
# MAGIC -- Step 2.1: Create row number
# MAGIC row_number_transactions as (
# MAGIC     select
# MAGIC         *,
# MAGIC         ROW_NUMBER() over (
# MAGIC             partition by transaction_id
# MAGIC             order by transaction_date desc
# MAGIC         ) AS row_number
# MAGIC     FROM filtered_transactions
# MAGIC )
# MAGIC
# MAGIC -- Step 2.2: Filter one row per primary key and select final table
# MAGIC SELECT
# MAGIC     transaction_id,
# MAGIC     date,
# MAGIC     category,
# MAGIC     amount
# MAGIC FROM row_number_transactions
# MAGIC WHERE row_number = 1

# COMMAND ----------

# MAGIC %md
# MAGIC ## PySpark SCD type 2 to DBT Snapshot
# MAGIC
# MAGIC ### Usecase
# MAGIC
# MAGIC Source table
# MAGIC | customer_id     | first_name     | last_name     | status     | last_updated           |
# MAGIC |-----------------|----------------|---------------|------------|------------------------|
# MAGIC | 1001            | John           | Smith         | Active     | 2024-01-02 10:15:00    |
# MAGIC | 1002            | Lucy           | Garcia        | Inactive   | 2024-01-03 12:00:00    |
# MAGIC | 1003            | Adam           | Johnson       | Active     | 2024-01-04 08:30:00    |
# MAGIC | 1004            | Maria          | Rossi         | Active     | 2024-01-05 14:45:00    |
# MAGIC | 1005            | Peter          | Chan          | Pending    | 2024-01-06 09:10:00    |
# MAGIC
# MAGIC Sink table
# MAGIC | customer_id     | first_name     | last_name     | status     | last_updated           | valid_from             | valid_to          | *is_current*     |
# MAGIC |-----------------|----------------|---------------|------------|------------------------|------------------------|------------------------|--------------|
# MAGIC | 1001            | John           | Smith         | Active     | 2024-01-02 10:15:00    | 2024-01-02 10:15:00    | 2024-01-10 09:00:00    | *false*        |
# MAGIC | 1001            | Johnny         | Smith         | Active     | 2024-01-10 09:00:00    | 2024-01-10 09:00:00    | null                   | *true*         |
# MAGIC | 1002            | Lucy           | Garcia        | Inactive   | 2024-01-03 12:00:00    | 2024-01-03 12:00:00    | null                   | *true*          |
# MAGIC | 1003            | Adam           | Johnson       | Active     | 2024-01-04 08:30:00    | 2024-01-04 08:30:00    | null                   | *true*          |
# MAGIC | 1004            | Maria          | Rossi         | Active     | 2024-01-05 14:45:00    | 2024-01-05 14:45:00    | null                   | *true*          |
# MAGIC | 1005            | Peter          | Chan          | Pending    | 2024-01-06 09:10:00    | 2024-01-06 09:10:00    | 2024-01-08 18:30:00    | *false*        |
# MAGIC | 1005            | Peter          | Chan          | Active     | 2024-01-08 18:30:00    | 2024-01-08 18:30:00    | null                   | *true*          |
# MAGIC
# MAGIC [DBT snapshots documentation](https://docs.getdbt.com/docs/build/snapshots)
# MAGIC
# MAGIC ### Migration step by step
# MAGIC
# MAGIC | PySpark Code | DBT SQL Code |
# MAGIC |---------|---------|
# MAGIC | <img src='./media/pyspark_scd2_to_dbt_dql_snapshot_1_pyspark.png'> | <img src='./media/pyspark_scd2_to_dbt_dql_snapshot_1_sql.png'> |
# MAGIC | <img src='./media/pyspark_scd2_to_dbt_dql_snapshot_2_pyspark.png'> | <img src='./media/pyspark_scd2_to_dbt_dql_snapshot_2_sql.png'> |

# COMMAND ----------

# MAGIC %md
# MAGIC ### PySpark code

# COMMAND ----------

# Step 1.1: Load source table
df_source = spark.read.table("customers_table")

# Step 1.2: Load sink table
deltaTable = DeltaTable.forName(spark, "scd2_customers")

# Step 2: Save data
(deltaTable.alias("t")
  .merge(
    source=df_source.alias("s"),
    condition="t.customer_id = s.customer_id AND t.is_current = true"
  )
  .whenMatchedUpdate(
    condition="""
      t.first_name <> s.first_name OR
      t.last_name <> s.last_name OR
      t.status <> s.status OR
      t.last_updated <> s.last_updated
    """,
    set={
        "valid_to": "current_timestamp()",
        "is_current": "false"
    }
  )
  .whenNotMatchedInsert(
    values={
        "customer_id": "s.customer_id",
        "first_name": "s.first_name",
        "last_name": "s.last_name",
        "status": "s.status",
        "last_updated": "s.last_updated",
        "valid_from": "current_timestamp()",
        "valid_to": "null",
        "is_current": "true"
    }
  )
  .execute()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DBT SQL code

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Step 2: Define snapshot logic
# MAGIC {% snapshot scd2_customers %}
# MAGIC   {{ config(
# MAGIC       unique_key='customer_id',
# MAGIC       strategy='timestamp',
# MAGIC       updated_at='last_updated',
# MAGIC   ) }}
# MAGIC
# MAGIC -- Step1: Load data
# MAGIC   SELECT
# MAGIC       customer_id,
# MAGIC       first_name,
# MAGIC       last_name,
# MAGIC       status,
# MAGIC       last_updated
# MAGIC   FROM {{ ref('customers_table') }}
# MAGIC
# MAGIC {% endsnapshot %}

# COMMAND ----------

# MAGIC %md
# MAGIC ## TIP Databricks DLT table to DBT streaming_table
# MAGIC
# MAGIC Here is a [Medium article](https://medium.com/@kiransreekumar/streaming-tables-in-databricks-and-integration-with-dbt-08443de4bd44) which ilustrates how DLT pipelines integrates with DBT.
# MAGIC
# MAGIC Also this is the [streaming table documentation](https://docs.getdbt.com/reference/resource-configs/databricks-configs#materialized-views-and-streaming-tables-1) from DBT.

# COMMAND ----------

# MAGIC %md
# MAGIC # Test and Validation

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## DBT Unit Test
# MAGIC
# MAGIC [Unit tests in DBT](https://docs.getdbt.com/docs/build/unit-tests), introduced in DBT v1.8, validate SQL model logic using static input data before materializing the full model in production. Unlike traditional DBT data tests, which assess data quality after model execution, unit tests help verify transformation logic in isolation.
# MAGIC
# MAGIC ### Key Features
# MAGIC
# MAGIC - Validate SQL transformation logic, not data quality.  
# MAGIC - Enable test-driven development (TDD) for better efficiency and reliability.  
# MAGIC - Available only for SQL models in the current DBT project.  
# MAGIC - Not supported for:
# MAGIC   - Materialized views 
# MAGIC   - Recursive SQL  
# MAGIC   - Introspective queries  
# MAGIC - Must be defined in YML files inside the models/ directory.  
# MAGIC - If a model has multiple versions, tests will run on all by default.  
# MAGIC - Important: To test joins, table names must be aliased.
# MAGIC
# MAGIC ### When to Use Unit Tests
# MAGIC
# MAGIC Unit tests should be implemented when:
# MAGIC - The SQL contains complex logic, such as:
# MAGIC   - Regular expressions
# MAGIC   - Date calculations
# MAGIC   - Window functions
# MAGIC   - CASE WHEN statements with multiple conditions
# MAGIC   - Truncations
# MAGIC - Writing custom SQL logic to process input data.
# MAGIC - Previous bugs were reported in the model logic.
# MAGIC - Edge cases that haven’t yet appeared in production data.
# MAGIC - Significant refactoring of transformation logic.
# MAGIC - The model is critical (e.g., public models or those used in key dashboards).
# MAGIC
# MAGIC ### When to Run Unit Tests
# MAGIC - DBT recommends running them only in development and CI/CD environments since they use static inputs.
# MAGIC - They should not be executed in production.
# MAGIC - To exclude them from dbt build, use: `dbt test --exclude-resource-type unit_test` or configure DBT_EXCLUDE_RESOURCE_TYPES in the environment.
# MAGIC
# MAGIC ### Example of a Unit Test in DBT
# MAGIC
# MAGIC This example creates a new `dim_customers` model with a field `is_valid_email_address` that calculates whether or not the customer’s email is valid:
# MAGIC
# MAGIC Model to Test (dim_customers.sql)
# MAGIC
# MAGIC ```sql
# MAGIC WITH customers AS (
# MAGIC     SELECT * FROM {{ ref('stg_customers') }}
# MAGIC ),
# MAGIC accepted_email_domains AS (
# MAGIC     SELECT * FROM {{ ref('top_level_email_domains') }}
# MAGIC ),
# MAGIC check_valid_emails AS (
# MAGIC     SELECT
# MAGIC         customers.customer_id,
# MAGIC         customers.email,
# MAGIC         COALESCE(
# MAGIC             REGEXP_LIKE(customers.email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
# MAGIC             AND accepted_email_domains.tld IS NOT NULL,
# MAGIC             FALSE
# MAGIC         ) AS is_valid_email_address
# MAGIC     FROM customers
# MAGIC     LEFT JOIN accepted_email_domains
# MAGIC     ON customers.email_top_level_domain = LOWER(accepted_email_domains.tld)
# MAGIC )
# MAGIC SELECT * FROM check_valid_emails
# MAGIC ```
# MAGIC
# MAGIC Unit Test Definition (models/unit_tests.yml)
# MAGIC
# MAGIC ```yml
# MAGIC unit_tests:
# MAGIC   - name: test_is_valid_email_address
# MAGIC     description: "Validate email logic for valid/invalid cases."
# MAGIC     model: dim_customers
# MAGIC     given:
# MAGIC       - input: ref('stg_customers')
# MAGIC         rows:
# MAGIC           - { email: "cool@example.com", email_top_level_domain: "example.com" }
# MAGIC           - { email: "cool@unknown.com", email_top_level_domain: "unknown.com" }
# MAGIC           - { email: "badgmail.com", email_top_level_domain: "gmail.com" }
# MAGIC           - { email: "missingdot@gmailcom", email_top_level_domain: "gmail.com" }
# MAGIC       - input: ref('top_level_email_domains')
# MAGIC         rows:
# MAGIC           - { tld: "example.com" }
# MAGIC           - { tld: "gmail.com" }
# MAGIC     expect:
# MAGIC       rows:
# MAGIC         - { email: "cool@example.com", is_valid_email_address: true }
# MAGIC         - { email: "cool@unknown.com", is_valid_email_address: false }
# MAGIC         - { email: "badgmail.com", is_valid_email_address: false }
# MAGIC         - { email: "missingdot@gmailcom", is_valid_email_address: false }
# MAGIC ```
# MAGIC
# MAGIC Running the Unit Test  
# MAGIC `dbt test --select test_is_valid_email_address`  
# MAGIC If the test fails, DBT will show the differences between the expected and actual results.
# MAGIC
# MAGIC ### Exit Codes for Unit Tests
# MAGIC - Pass (0)
# MAGIC - Fail (1)  
# MAGIC Unlike data tests, unit tests have only two possible outcomes (pass or fail), regardless of how many records failed.
# MAGIC
# MAGIC ### Summary
# MAGIC - Unit tests validate SQL logic before materializing models.
# MAGIC - They use static mock data in YML files.
# MAGIC - Recommended for complex logic, refactoring, and critical models.
# MAGIC - Should not be run in production, only in development and CI/CD.
# MAGIC - Supported for incremental models, but require additional configurations.
# MAGIC - Results are binary (pass/fail) and help catch errors before they impact real data.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Validation
# MAGIC
# MAGIC ### Requirements
# MAGIC - The model is already migrated
# MAGIC - Legacy and migrated model can run in parallel
# MAGIC
# MAGIC ### Description
# MAGIC When migrating a data processing model from PySpark to dbt (Data Build Tool), it is crucial to ensure that the new implementation produces consistent and accurate results. Drawing a parallel with the machine learning **champion-challenger** approach, you can treat the original PySpark model as the **champion** (the existing proven solution) and the dbt model as the **challenger** (the new solution). You then compare the results of both models to confirm that the new dbt model behaves correctly and meets the same (or improved) quality standards.
# MAGIC
# MAGIC In a **champion-challenger** setup, both models run in parallel for a certain period. During this period, you compare their outputs, ensuring that if there are differences, they are justified and within acceptable thresholds. Once you are confident in the new solution, you can transition fully to the dbt model as the **champion**.
# MAGIC
# MAGIC ### Key Points
# MAGIC 1. Champion-Challenger Concept
# MAGIC    - The champion is the existing, trusted model.
# MAGIC    - The challenger is the new model.
# MAGIC    - Both run in parallel to compare performance and validate outputs.
# MAGIC 1. Data Validation Principles
# MAGIC    - Compare key metrics, aggregations, or final results from both models.
# MAGIC    - Use thresholds or tolerance levels to decide what is considered an acceptable difference.
# MAGIC    - Document discrepancies and investigate significant deviations.
# MAGIC 1. Validation Strategy
# MAGIC    - Run the PySpark model (**champion**) and dbt model (**challenger**) on the same source data.
# MAGIC    - Compare the outputs.
# MAGIC
# MAGIC ### Example
# MAGIC Imagine you have a daily sales data model. Previously, you processed the data in PySpark:
# MAGIC ##### 1. Original PySpark Model (Champion)
# MAGIC ```python
# MAGIC from pyspark.sql.functions import sum, col
# MAGIC
# MAGIC # Load data
# MAGIC df_sales = spark.read.format("csv").option("header", True).load("sales_data.csv")
# MAGIC
# MAGIC # Data transformations
# MAGIC df_agg = df_sales.groupBy("region") \
# MAGIC                  .agg(sum(col("sales_amount")).alias("total_sales"))
# MAGIC
# MAGIC # Save aggregated results
# MAGIC df_agg.write.format("parquet").mode("overwrite").save("/path/to/output")
# MAGIC ```
# MAGIC
# MAGIC ##### 2. New dbt Model (Challenger)
# MAGIC In dbt, you use SQL-based models and tests. Suppose you have a model file sales_agg.sql:
# MAGIC ```sql
# MAGIC SELECT
# MAGIC     region,
# MAGIC     SUM(sales_amount) AS total_sales
# MAGIC FROM {{ ref('sales_data') }}
# MAGIC GROUP BY region
# MAGIC ```
# MAGIC
# MAGIC ##### 3. Validation
# MAGIC - Schedule both models (PySpark and dbt) to run on the same source data.
# MAGIC - Load both models in a notebook, if the volume is high load small partitions.
# MAGIC - Compare the results:
# MAGIC ```sql
# MAGIC SELECT
# MAGIC   challenger.region,
# MAGIC   champion.total_sales AS champion_total_sales,
# MAGIC   challenger.total_sales AS challenger_total_sales,
# MAGIC   (challenger.total_sales - champion.total_sales) AS difference
# MAGIC FROM champion_table champion
# MAGIC JOIN challenger_table challenger 
# MAGIC    ON champion.region = challenger.region
# MAGIC ```
# MAGIC
# MAGIC ### Conclusion
# MAGIC By treating the original PySpark model as the **champion** and the new dbt model as the **challenger**, you can methodically validate that the two solutions produce equivalent results. This process reduces risks during migration, ensures data integrity, and builds confidence that your new dbt model is ready to become the standard production model.

# COMMAND ----------

# MAGIC %md
# MAGIC # Support Tools
# MAGIC
# MAGIC ## AI models to translate code
# MAGIC
# MAGIC I recommend using [PySpark SQL Interchange](https://www.yeschat.ai/gpts-9t55QZk96ai-PySpark-SQL-Interchange) or **Chat GPT** to translate PySpark code into SQL.
# MAGIC Key notes:
# MAGIC - When translating code from one language to another specify the version of PySpark and the SQL dialect.
# MAGIC - For Simple or moderate PysPark models try to organize the code then ask for translation.
# MAGIC - For complex PySpark models use the output of the method `explain` of dataframes instead of the PySpark code.
# MAGIC
# MAGIC [`explain()`](https://sparkbyexamples.com/spark/spark-execution-plan/) method to display the Spark execution plan.
# MAGIC
# MAGIC ## DBT - Compiled code
# MAGIC
# MAGIC To check out the SQL that dbt is running, you can look in:
# MAGIC - The `target/compiled/` directory for compiled select statements
# MAGIC - The `target/run/` directory for compiled create statements
# MAGIC - The `logs/dbt.log` file for verbose logging.

# COMMAND ----------

# MAGIC %md
# MAGIC # Steps to Follow to Migrate
# MAGIC
# MAGIC 1. **Know the main differences between PySpark and DBT**
# MAGIC 1. **Identify the kind of data you want to migrate (transactional, master,...) and the data volumetry**
# MAGIC 1. **Identify the type of PySpark model and choose the correct DBT materialization accordingly**
# MAGIC 1. **Consider adding unit test to the migrated DBT SQL model**
# MAGIC 1. **Define a validation process that allows you to compare both the legacy PySpark model and the migrated DBT SQL model**
# MAGIC 1. **Once data is validated, decomission the legacy PySpark model and promote the DBT SQL model to production**